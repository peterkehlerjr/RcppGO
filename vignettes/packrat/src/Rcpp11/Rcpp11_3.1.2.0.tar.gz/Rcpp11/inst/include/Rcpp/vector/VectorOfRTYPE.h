#ifndef Rcpp__vector_VectorOfRTYPE_h
#define Rcpp__vector_VectorOfRTYPE_h

namespace Rcpp{
    template <int RTYPE> struct VectorOfRTYPE{} ;     
}

#endif
