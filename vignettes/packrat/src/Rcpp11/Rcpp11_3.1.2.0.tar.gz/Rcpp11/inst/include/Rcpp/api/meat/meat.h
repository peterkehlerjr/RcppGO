#ifndef Rcpp_api_meat_meat_h
#define Rcpp_api_meat_meat_h

#include <Rcpp/api/meat/NamesProxy.h>
#include <Rcpp/api/meat/is.h>
#include <Rcpp/as/as.h>
#include <Rcpp/api/meat/sugar.h>
#include <Rcpp/api/meat/wrap.h>

#endif
