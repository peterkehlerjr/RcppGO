#ifndef RCPP_SUGAR_LAZY_H
#define RCPP_SUGAR_LAZY_H

#include <Rcpp/sugar/lazy/get_size.h>
#include <Rcpp/sugar/lazy/TupleWrapper.h>
#include <Rcpp/sugar/lazy/create.h>
#include <Rcpp/sugar/lazy/fuse.h>
#include <Rcpp/sugar/lazy/c.h>

#endif
