#ifndef Rcpp__stats__stats_h
#define Rcpp__stats__stats_h

#include <Rcpp/stats/dpq.h>
#include <Rcpp/stats/random/random.h>

#endif
