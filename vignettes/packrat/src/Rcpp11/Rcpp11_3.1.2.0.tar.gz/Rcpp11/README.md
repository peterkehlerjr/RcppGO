Rcpp11
=======

[![Build Status](https://travis-ci.org/Rcpp11/Rcpp11.png)](https://travis-ci.org/Rcpp11/Rcpp11)

`Rcpp11` is a complete redesign of `Rcpp`, targetting C++11.

Feel free to ask questions, discuss feature requests and otherwise on
the [mailing list](https://groups.google.com/forum/#!forum/r-and-cpp).
