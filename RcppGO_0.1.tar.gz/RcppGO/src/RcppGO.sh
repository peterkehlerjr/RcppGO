#!/bin/bash  

## find directory of file
ABSPATH=$(cd "$(dirname "$0")"; pwd)
cd $ABSPATH

FILENAME=RcppGO

## remove old files
rm -rf *.o *.so 

# export librarys to PATH
RCPP_CXXFLAGS=`Rscript -e 'Rcpp:::CxxFlags()'`
RCPP_LIBS=`Rscript -e 'Rcpp:::LdFlags()'`


## insert os dependent compiler instructions
OSTYPE=`uname`


## on Ubuntu 
if [ OSTYPE=Linux ]; then

    R_HOME="R/x86_64-pc-linux-gnu-library/2.15/RcppArmadillo/include"

    if [ -d $HOME/$R_HOME ]; then

	export PKG_CPPFLAGS="-I${HOME}/${R_HOME} ${RCPP_CXXFLAGS}"
	export PKG_LIBS="-larmadillo -llapack  ${RCPP_LIBS}"

    else
	echo ""
	echo "Warning:"
	echo "RcppArmadillo is not installed in $HOME$R_HOME"
	echo ""
    fi
fi


## on OSX 
if [ OSTYPE=Darwin ]; then

    R_HOME="/Library/Frameworks/R.framework/Versions/2.15/Resources/library/RcppArmadillo/include"
    
else
     echo "Your OS is $OSTYPE."

    if [ -d $HOME/$R_HOME ]; then

	export PKG_CPPFLAGS="-I${HOME}/${R_HOME} ${RCPP_CXXFLAGS}"
	export PKG_LIBS="-larmadillo -llapack  ${RCPP_LIBS}"

    else
	echo ""
	echo "Warning:"
	echo "RcppArmadillo is not installed in $HOME$R_HOME"
	echo ""
    fi
fi

## todo: add Windows support

# do you want to use the GCC compiler (GCC=true) or the R compiler (GCC=false) 
#echo ""
#echo "Do you want to use the g++ compiler (true) or the default R compiler options (false)"
#read GCC 

GCC=false


if [ $GCC == false ]; then
    # compile using R
    R CMD SHLIB $FILENAME.cpp -o $FILENAME.so
else
    ## manual compilation with gcc =========================== ##
    compiler="g++"

    $compiler -I/usr/share/R/include -DNDEBUG -I/home/pkehler/R/x86_64-pc-linux-gnu-library/2.15/RcppArmadillo/include -I/home/pkehler/R/x86_64-pc-linux-gnu-library/2.15/Rcpp/include  -fpic  -O3 -pipe  -g  -c $FILENAME.cpp -o $FILENAME.o


    $compiler -shared -o $FILENAME.so $FILENAME.o -L/home/pkehler/R/x86_64-pc-linux-gnu-library/2.15/Rcpp/lib -lRcpp -Wl,-rpath,/home/pkehler/R/x86_64-pc-linux-gnu-library/2.15/Rcpp/lib -llapack -lblas -lgfortran -lm -lquadmath -L/usr/lib/R/lib -lR

fi


